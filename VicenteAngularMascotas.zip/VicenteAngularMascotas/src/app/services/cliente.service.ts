import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Cliente } from './../interfaces/cliente';

@Injectable({
  providedIn: 'root'
})
export class ClienteService {
  private host="http://localhost:8000/"

  constructor(private http: HttpClient) { }
  getAllclientes(){
    const path=`${this.host}clientes/allJson`;
    return this.http.get<Cliente>(path,{
      headers:{
    'Content-Type':'application/json'}

    });
  }
  createCliente(cliente: Cliente){
    const path=`${this.host}crearcuenta`;
    return this.http.post(path,cliente,{
      headers:{
      'Content-Type':'application/json'}

    });

  }

}
