import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Turnos } from './../interfaces/turnos';
@Injectable({
  providedIn: 'root'
})
export class TurnosService {

  private host = "http://localhost:8000/turnos"

  constructor(private http: HttpClient) { }
  getAllTurnos() {
    const path = `${this.host}/all`;
    return this.http.get<Turnos[]>(path, {
      headers: { 'Content-Type': 'application/json' }
    });
    }
    getAllTcedula(cedu: string) {
      const path = `${this.host}/getTce/${cedu}`;
      return this.http.get<Turnos>(path, {
        headers: { 'Content-Type': 'application/json' }
      });
      }
      getAllTinfo() {
        const path = `${this.host}/getTinfor`;
        return this.http.get<Turnos[]>(path, {
          headers: { 'Content-Type': 'application/json' }
        });
        }

        createTurno(turno: Turnos){
          const path=`${this.host}/create`;
          return this.http.post(path,turno,{
            headers:{
            'Content-Type':'application/json'}
            
          });
      
        }
  }