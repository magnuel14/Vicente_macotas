import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Mascota } from './../interfaces/mascota';

@Injectable({
  providedIn: 'root'
})
export class MascotasService {
  private host = "http://localhost:8000/mascotas"

  constructor(private http: HttpClient) { }
  getAllMascotas() {
    const path = `${this.host}/all`;
    return this.http.get<Mascota>(path, {
      headers: { 'Content-Type': 'application/json' }
    });
    }
    createMascota(mascota: Mascota){
      const path=`${this.host}/create`;
      return this.http.post(path,mascota,{
        headers:{
        'Content-Type':'application/json'}
        
      });
  
    }
  }