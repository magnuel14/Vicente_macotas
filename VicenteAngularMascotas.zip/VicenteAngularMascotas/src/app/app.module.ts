import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
//permite conectar conectar la vista con el componente logico
import { FormsModule } from '@angular/forms';
//
import { HttpClientModule } from '@angular/common/http';


import { AppComponent } from './app.component';
import { ClienteComponent } from './components/cliente/cliente.component';
import { UsuarioComponent } from './components/usuario/usuario.component';
import { MascotasComponent } from './components/mascotas/mascotas.component';
import { TurnosComponent } from './components/turnos/turnos.component';

@NgModule({
  declarations: [
    AppComponent,
    ClienteComponent,
    UsuarioComponent,
    MascotasComponent,
    TurnosComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
