import { Component, OnInit } from '@angular/core';
import { MascotasService } from './../../services/mascotas.service';
import { Mascota } from './../../interfaces/mascota';

@Component({
  selector: 'app-mascotas',
  templateUrl: './mascotas.component.html',
  styleUrls: ['./mascotas.component.css']
})
export class MascotasComponent {

  constructor(private mascota_servicio: MascotasService) { }

  mascotaNueva: Mascota = {
    numero_mas: "",
    nombres_mas: "",
    raza: "",
    edad: "",
    cliente_id: "",

  };


  getAllMascotas() {
    this.mascota_servicio.getAllMascotas().subscribe(datos => {
      console.log(datos);

    });

  }
  createMascota() {
    this.mascota_servicio.createMascota(this.mascotaNueva).subscribe(datos => {
      console.log(datos);
    })

  }
}