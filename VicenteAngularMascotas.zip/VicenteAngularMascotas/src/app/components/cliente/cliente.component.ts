import { Component } from '@angular/core';
import { ClienteService } from './../../services/cliente.service';
import { Cliente } from './../../interfaces/cliente';


@Component({
  selector: 'app-cliente',
  templateUrl: './cliente.component.html',
  styleUrls: ['./cliente.component.css']
})
export class ClienteComponent {

  constructor(private usuario_servicio: ClienteService) { }
  clienteNuevo: Cliente = {
    cedula: "",
    nombres: "",
    apellidos: "",
    celular: "",
    telefono: "",
    correo: "",
    clave: "",
  };

  getAllclientes() {
    this.usuario_servicio.getAllclientes().subscribe(datos=>{
      console.log(datos);
    })

  }
  createCliente(){
    this.usuario_servicio.createCliente(this.clienteNuevo).subscribe(datos=>{
      console.log(datos);
    })

  }
}