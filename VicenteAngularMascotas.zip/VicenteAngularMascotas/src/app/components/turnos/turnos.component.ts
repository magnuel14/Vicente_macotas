import { Component, OnInit } from '@angular/core';
import { TurnosService } from './../../services/turnos.service';
import { Turnos } from './../../interfaces/turnos';
import { Cliente } from './../../interfaces/cliente';

@Component({
  selector: 'app-turnos',
  templateUrl: './turnos.component.html',
  styleUrls: ['./turnos.component.css']
})
export class TurnosComponent {

  constructor(private turno_service: TurnosService) { }

  clienteBusqueda: Cliente = {
    cedula: "",
    nombres: "",
    apellidos: "",
    celular: "",
    telefono: "",
    correo: "",
    clave: "",
    api_token: "",

  };
  TurnoNuevo: Turnos = {
    fecha: "",
    tipo: "",
    descripcion: "",
    mascota_id: "",
  };


  getAllTurnos() {
    this.turno_service.getAllTurnos().subscribe(datos => {
      console.log(datos);

    });


  }

  getAllTcedula() {
    this.turno_service.getAllTcedula(this.clienteBusqueda.cedula).subscribe(datos => {
      console.log(datos);

    });
  }
  getAllTinfo() {
    this.turno_service.getAllTinfo().subscribe(datos => {
      console.log(datos);

    });


  }
  createTurno(){
    this.turno_service.createTurno(this.TurnoNuevo).subscribe(datos=>{
      console.log(datos);
    })

  }

}
