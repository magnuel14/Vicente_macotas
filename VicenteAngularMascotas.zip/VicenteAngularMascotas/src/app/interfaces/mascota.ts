export interface Mascota {
    numero_mas: string;
    nombres_mas: string;
    raza: string;
    edad:string;
    cliente_id: string;
    
}
