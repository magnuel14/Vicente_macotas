export interface Turnos {
    fecha: string;
    tipo: string;
    descripcion: string;
    mascota_id:string;
   
}

