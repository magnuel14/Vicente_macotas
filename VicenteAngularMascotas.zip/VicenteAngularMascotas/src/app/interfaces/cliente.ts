export interface Cliente {
    cedula: string;
    nombres: string;
    apellidos: string;
    celular:string;
    telefono: string;
    correo: string;
    clave:string;
    api_token?:string;
    data_created?: string;
}
