export interface Usuario {
    username: string;
    email:string;
}
